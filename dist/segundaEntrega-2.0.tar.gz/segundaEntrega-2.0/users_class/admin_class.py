from users_class import User;

class Admin(User):
    