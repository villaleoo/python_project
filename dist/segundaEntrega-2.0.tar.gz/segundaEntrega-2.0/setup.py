from setuptools import setup

setup(
    name="segundaEntrega",
    version="2.0",
    author='leopoldo',
    description='segunda entrega proyecto',
    author_email="villaleoo@gmail.com",
    packages=["data_clients", "users_class"]
)